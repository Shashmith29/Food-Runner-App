package com.internshala.foodrunner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ForgotPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_page)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
    }
}