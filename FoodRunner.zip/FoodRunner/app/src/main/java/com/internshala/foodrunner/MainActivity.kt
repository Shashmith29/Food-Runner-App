package com.internshala.foodrunner

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

lateinit var ForgotPassword: TextView
lateinit var SignUp: TextView
class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ForgotPassword = findViewById(R.id.txtForgotPassword)
        SignUp = findViewById(R.id.txtSignUp)
        ForgotPassword.setOnClickListener {
            intent = Intent(this,ForgotPage::class.java)
            startActivity(intent)
        }
        SignUp.setOnClickListener {
            intent = Intent(this,Register_Activity::class.java)
            startActivity(intent)
        }


    }
}